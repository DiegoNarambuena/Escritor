# isgcs2022
Ingeniería de Software - GCS -  2022
