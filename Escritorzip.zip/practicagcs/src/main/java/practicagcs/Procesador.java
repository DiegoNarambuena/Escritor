package practicagcs;

import java.util.LinkedList;
import java.util.List;

public class Procesador {
	
	public Procesador() {//somos el team escritor
	}
	List<Salida> LiSa = new LinkedList<>();
	public List<Salida> llenar(){
		Salida s1 = new Salida("1", "Chubut", 40.32);
		Salida s2 = new Salida("2", "Rosario", 32.40);
		Salida s3 = new Salida("3", "Tierra del Fuego", 45.50);
		LiSa.add(s1);
		LiSa.add(s2);
		LiSa.add(s3);
		
		return LiSa;
	}
	
}