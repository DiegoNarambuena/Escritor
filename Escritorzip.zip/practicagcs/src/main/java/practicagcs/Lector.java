package practicagcs;

public class Lector {

}
