package practicagcs;

import java.util.LinkedList;
import java.util.List;

public class Escritor {

	List<Salida> proyectar = new LinkedList<>();
	
	public void algo() {
		proyectar = Procesador.llenar();
		for(Salida p: proyectar) {
			
		}
	}
	
}
