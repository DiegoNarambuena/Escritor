package practicagcs;

public class Salida {
	private String idProceso;
	private String campo;
	private Double total;
	
	public Salida (String idProceso, String campo, double total){
		this.idProceso = idProceso;
		this.campo = campo;
		this.total = total;
	}
	public String getIdProceso() {
		return idProceso;
	}
	public String getCampo() {
		return campo;
	}
	public Double getTotal() {
		return total;
	}
}